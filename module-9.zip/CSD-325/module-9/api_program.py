"""
Name: Aaron Provins
Course: CSD-325
Assignment: Module 9 - APIs
File: api_program.py
Description:
    1. Test connection to the astronauts API.
    2. Print astronauts (raw + formatted).
    3. Use a second API and show raw + formatted output.
"""

import requests

# -----------------------------
# PART 1: ASTRONAUTS API (TUTORIAL)
# -----------------------------
ASTRO_URL = "http://api.open-notify.org/astros.json"

def test_connection(url):
    print(f"Testing connection to: {url}")
    response = requests.get(url)
    print("Status code:", response.status_code)
    return response

def print_raw_response(response):
    print("\n--- RAW RESPONSE ---")
    print(response.text)

def print_astronauts_formatted(data):
    print("\n--- FORMATTED ASTRONAUT OUTPUT ---")
    print(f"Message: {data.get('message')}")
    print(f"Number of people in space: {data.get('number')}")
    print("\nPeople:")
    for person in data.get("people", []):
        print(f"- {person['name']} on {person['craft']}")

# -----------------------------
# PART 2: SECOND SIMPLE API
# -----------------------------
BORED_URL = "https://www.boredapi.com/api/activity"

def print_bored_formatted(data):
    print("\n--- FORMATTED BORED API OUTPUT ---")
    print(f"Activity: {data.get('activity')}")
    print(f"Type: {data.get('type')}")
    print(f"Participants: {data.get('participants')}")
    print(f"Price: {data.get('price')}")

# -----------------------------
# MAIN PROGRAM
# -----------------------------
def main():
    print("===== PART 1: Astronauts API =====")
    astro_response = test_connection(ASTRO_URL)
    print_raw_response(astro_response)
    astro_data = astro_response.json()
    print_astronauts_formatted(astro_data)

    print("\n\n===== PART 2: Second API (Bored API) =====")
    bored_response = test_connection(BORED_URL)
    print_raw_response(bored_response)
    bored_data = bored_response.json()
    print_bored_formatted(bored_data)

if __name__ == "__main__":
    main()
