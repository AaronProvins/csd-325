"""
Name: Aaron Provins
Course: CSD-325
Assignment: Module 9 - API Connection Test
File: connection_test.py
Description:
    Simple program to test an HTTP connection to the astronauts API.
"""

import requests

# URL from the tutorial (Open Notify Astronaut API)
API_URL = "http://api.open-notify.org/astros.json"

def main():
    print("Testing connection to:", API_URL)
    response = requests.get(API_URL)
    
    print("Status code:", response.status_code)
    print("\nRaw response text:")
    print(response.text)

if __name__ == "__main__":
    main()
